//
//  iPhone_target2AppDelegate.h
//  iPhone-target2
//
//  Created by Renaldas on 8/22/08.
//  Copyright __MyCompanyName__ 2008. All rights reserved.
//

#import <UIKit/UIKit.h>

@class iPhone_target2ViewController;

@interface iPhone_target2AppDelegate : NSObject <UIApplicationDelegate> {
	IBOutlet UIWindow *window;
}

@property (nonatomic, retain) UIWindow *window;

@end

